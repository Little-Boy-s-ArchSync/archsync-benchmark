/* generated - don't edit */
module.exports = {
	version: "18.3.0",
	engines: {
		node: "^22||^24||>=26",
	},
	supportedTranspilers: {
		babel: ">=7.0.0 <8.0.0",
		"coffee-script": ">=1.0.0 <2.0.0",
		coffeescript: ">=1.0.0 <3.0.0",
		livescript: ">=1.0.0 <2.0.0",
		svelte: ">=3.0.0 <6.0.0",
		swc: ">=1.0.0 <2.0.0",
		typescript: ">=2.0.0 <7.0.0",
		"vue-template-compiler": ">=2.0.0 <3.0.0",
		"@vue/compiler-sfc": ">=3.0.0 <4.0.0",
	},
};
